Blockly.Msg.CHEMKID_GET_LUX_TITLE = "ChemKid: ";
Blockly.Msg.CHEMKID_GET_LUX_TOOLTIP = "Return: R-G-B Color or Concentration Value";
Blockly.Msg.CHEMKID_GET_LUX_HELPURL = "";
